
public class ejercicio5Poo {
	public class CajeroAutomatico {

		private String nombre;
		private String sucursal;
		private int dinero;
		public void retener() {
			
		}
		public void insertar() {
			
		}
		public void extraer() {
			
		}

	}
}