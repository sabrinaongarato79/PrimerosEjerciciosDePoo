package ejercicio4Poo;

public class privateString {

}
