
public class ejercicio3Poo {

private int numeroDeSerie;
private int capacidadDePersonas ;
private double alturaMaxima;
public void volar() {
	
}

public void aterrizar() {
	
}

}