package ejercicio2Poo;

public class Ascensor {

	private int numeroDeSerie;
	private String marca;
	private int edad;
	public void subir() {
		
	}
	public void bajar() {
		
	}


}